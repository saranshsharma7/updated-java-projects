
package Buslogic;

import java.util.Date;
public interface intemp 
{
    public void setempcod(int ecod);
    public void setempnam(String enam);
    public void setemppic(String epic);
    public void setemploc(String eloc);
    public void setempphnno(String ephnno);
   
     public int getempcod();
    public String getempnam();
    public String getemppic();
    public String getemploc(); 
    public String getempphnno();
    
}
