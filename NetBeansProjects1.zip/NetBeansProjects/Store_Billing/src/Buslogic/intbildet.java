
package Buslogic;

import java.util.Date;


public interface intbildet {
    
    public void setbildetcod(int bdcod);
    public void setbildetbilcod(int bdbilcod);
    public void setbildetstkcod(int bdstkcod);
    public void setbildetqty(int bdqty);
   
    
    public int getbildetcod();
    public int getbildetbilcod();
    public int getbildetstkcod();
    public int getbildetqty();
}
